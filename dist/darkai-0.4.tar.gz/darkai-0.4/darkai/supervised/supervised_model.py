class supervised_model:
    _type = "supervised_model"
