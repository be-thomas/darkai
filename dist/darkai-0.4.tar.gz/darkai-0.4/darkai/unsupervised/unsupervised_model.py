class unsupervised_model:
    _type = "unsupervised_model"
