class optimizer:
    _type = "optimizer"
    