
class observer:
    _type = "observer"
